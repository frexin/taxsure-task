#!/bin/sh
service php7.1-fpm start
